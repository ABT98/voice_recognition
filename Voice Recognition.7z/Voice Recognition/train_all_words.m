function train_all_words
    warning('off','MATLAB:dispatcher:InexactCaseMatch');
    numStates = 5;	 
    % Train word 1 - Kirmizi
    train_word('Kirmizi', numStates);
    % Train word 2 - Mavi
    train_word('Mavi', numStates);
    % Train word 3 - Mor
    train_word('Mor', numStates);
    % Train word 4 - Sari
    train_word('Sari', numStates);
    % Train word 5 - Yesil
    train_word('Yesil', numStates);end