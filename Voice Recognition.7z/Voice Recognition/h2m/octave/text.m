function text(x,y,str)

%text      Does nothing (introduced for MATLAB compatibility)
%          Use: text(x,y,str).

% H2M/cnt Toolbox, Version 2.0
% Olivier Capp�, 15/04/99 - 15/04/99
% ENST Dpt. TSI / LTCI (CNRS URA 820), Paris

fprintf(1,['Sorry, I don''t know of to print ''' ...
  str ''' on the graphical display\n']);
