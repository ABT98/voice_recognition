function clf()

%clf       Clear current figure (introduced for MATLAB compatibility).
%          Use: clf.

% H2M/cnt Toolbox, Version 2.0
% Olivier Capp�, 31/12/98 - 31/12/98
% ENST Dpt. TSI / LTCI (CNRS URA 820), Paris

clg;
hold off;
