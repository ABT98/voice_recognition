function t = issparse(x)

%issparse  Returns 0 (introduced for MATLAB compatibility), assuming all
%          matrices are non-sparse.

% H2M/cnt Toolbox, Version 2.0
% Olivier Capp�, 15/04/99 - 15/04/99
% ENST Dpt. TSI / LTCI (CNRS URA 820), Paris

t = 0;
