function drawnow()

%drawnow   Does nothing (introduced for MATLAB compatibility).
%          Use: drawnow.

% H2M/cnt Toolbox, Version 2.0
% Olivier Capp�, 31/12/98 - 31/12/98
% ENST Dpt. Signal / CNRS URA 820, Paris

fprintf(1, 'Sory function drawnow not implemented.\n');
