function test_word( wordName, numStates )
	 
	% E?itimi tamamlanan ve HMM model dosyalar?
	% hmm_model_files kls�r�ne at?lm?? olan kelimeler listesi.
	trainedWords = {'Kirmizi';
	                'Mavi';
	                'Mor';
	                'Sari';
	                'Yesil'};
	 
	% Test edilecek wav dosya okunur ve cepstrum �retilir.
	wav_file_name = ['./testing_words/' wordName '.wav'];
	[y, fs] = audioread(wav_file_name);
	observationVector = melcepst(y, fs, '', 22, floor(3*log(fs)), 128, 32);
	
	% HMM Viterbi aramas?
	N = numStates;
	A = sparse(0.85*diag(ones(1,N))+0.15*diag(ones(1,N-1),1));
	A(N,N) = 1;
	numIter = 10;
	 
	numberOfFiles = length(trainedWords);
	 
	for w=1:numberOfFiles
	    fileName = trainedWords{w};
	    modelFileName = ['hmm_model_files/' fileName '.mat'];
	    load(modelFileName);
	 
	    Sigma = ones(N,1) * my_sigma;
	
	    % Viterbi aranas? vebir benzerlik skoru elde etmek
	    score(w) = hmm_vit(observationVector, A, [1 zeros(1,N-1)],  my_mu, Sigma, 1);
	end  % for w=3:num...
	 
	% Maksimum skoru veren kelime en iyi alg?lanan kelimedir
	result = score >= max(score);
	 
	disp(['Recognized word is ' trainedWords{result}]);
end