function [k,v]=findpeak(x,w,m)
% find peaks in waveform. peaks must be max for +-w samples (default=1)
% all found peaks will be at least w from the ends
% m='q' to use quadratic interpolation to find exact peaks
% v=x(k), possibly interpolated

%      Copyright (C) Mike Brookes 2003
%
%      Last modified Tue May 13 15:37:59 2003
%
%   VOICEBOX is a MATLAB toolbox for speech processing. Home page is at
%   http://www.ee.ic.ac.uk/hp/staff/dmb/voicebox/voicebox.html
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   This program is free software; you can redistribute it and/or modify
%   it under the terms of the GNU General Public License as published by
%   the Free Software Foundation; either version 2 of the License, or
%   (at your option) any later version.
%
%   This program is distributed in the hope that it will be useful,
%   but WITHOUT ANY WARRANTY; without even the implied warranty of
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%   GNU General Public License for more details.
%
%   You can obtain a copy of the GNU General Public License from
%   ftp://prep.ai.mit.edu/pub/gnu/COPYING-2.0 or by writing to
%   Free Software Foundation, Inc.,675 Mass Ave, Cambridge, MA 02139, USA.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nargin<3
    m=' ';
    if nargin<2
        w=1;
    end
end
[y,r]=maxfilt(x,1,2*w+1);
k=find(((2*w+1:length(x))'-r(2*w+1:end))==w)+w;
if any(m=='q')
    b=0.5*(x(k+1)-x(k-1));
    a=b+x(k-1)-x(k);
    v=x(k)-0.25*b.^2./a;
    k=k-0.5*b./a;
else
    v=x(k);
end
if nargout==0
    plot(1:length(x),x,'b',k,v,'+r');
end
 