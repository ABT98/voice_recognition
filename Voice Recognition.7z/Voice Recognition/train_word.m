function train_word( wordName, numStates )
	disp(['Egitilen kelime: ' wordName]);

    % wav dosya okunur ve �cepstrum� �retilir
	wav_file_name = ['./training_words/' wordName '.wav'];
	 
	[y, fs] = audioread(wav_file_name);
	observationVector = melcepst(y, fs, '', 22, floor(3*log(fs)), 128, 32);
	 
	% Parametrelerin e?itimi
	DIAG_COV = 1;   % Diyagonal kovaryans matrisleri kullan?ls?n
	QUIET = 1;      % E?itim rutinlerini �?kt? vermeden yap
	N = numStates;  % Kelime modelinin durum sayjs?

	% Ge�i? (ing: transition) matris birazc?k keyfidir
	% ve tahmini olmayacakt?r (�ok az s�zc�k var ��nk�)
	A = sparse(0.85*diag(ones(1,N))+0.15*diag(ones(1,N-1),1));
	A(N,N) = 1;
	NIT = 10;       % EM (Beklenti Maksimizasyonu) tekrarlar?n?n say?s?
	p = size(observationVector, 2);
	 
	X = [];
	st = [];
	st = [st; size(X,1)+1];
	X = [X; observationVector];
	T = size(X,1);
	 
	% E?itim verisi az oldu?undan kovaryans matrisleri diyagonaldir,
	% ve kelime modelindeki t�m durumlarca payla??l?r
	% (yani t�m durumlar Sigma isimli ayn? kovaryans? kullan?rlar).
	[my_mu,Sigma] = hmm_mint(X, st, N, DIAG_COV,QUIET);
	Sigma = ones(N,1)*mean(Sigma);       % Payla??lan konaryans
	logl = zeros(1, NIT);

	for n = 1:NIT
		% EM algoritmas?n?n beklenti ad?mlar?
		[tmp, logl(n), gamma] = hmm_mest(X, st, A, my_mu, Sigma, QUIET);
		% EM algoritmas?n?n k?s?ts?z maksimizasyon ad?m?
		[my_mu, Sigma] = mix_par(X, gamma, DIAG_COV, QUIET);
		% EM maksimizasyonunu d�zenlenmi? hali t�m kovaryans
		% matrislerinin birim matris olmas? k?s?t?na dayan?r. 			
        Sigma = ones(N,1)*(sum((sum(gamma)'*ones(1,p)).*Sigma)/T);
	end
	my_sigma = Sigma(1,:);
	 
	% Her kelimeye model klas�r�nde ayr? bir �mat� dosya yaz?l?r.
	eval(['save hmm_model_files/' wordName ' my_mu my_sigma']);
end